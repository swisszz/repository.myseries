# -*- coding: utf-8 -*-
import xbmcplugin
import xbmcgui
import sys
import urllib.parse

addon_handle = int(sys.argv[1])
args = urllib.parse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', [None])[0]

# THAI DIGITAL (Live TV)
live_channels = [
    {'name': 'CH7', 'url': 'https://lb1-live-mv.v2h-cdn.com/hls/ffac/7hd/7hd.m3u8', 'logo': 'https://n9.cl/4kmiht'},
    {'name': 'Nation', 'url': 'https://nationtv-1jdcjo.cdn.byteark.com/fleetstream/nationtvlive/1080p/index.m3u8', 'logo': 'https://n9.cl/pkxl3'},
    {'name': 'CH8', 'url': 'https://lb1-live-mv.v2h-cdn.com/hls/ffbe/ch8/ch8.m3u8', 'logo': 'https://n9.cl/d2ksaw'},
    {'name': 'Nation CHAK', 'url': 'https://lb1-live-mv.v2h-cdn.com/hls/ffcc/nation/nation.m3u8', 'logo': 'https://n9.cl/r0we5'},
    {'name': 'CH3 HD', 'url': 'https://lb1-live-mv.v2h-cdn.com/hls/ffae/3hd/3hd.m3u8', 'logo': 'https://n9.cl/9f0xf'},
    {'name': 'TNN', 'url': 'https://lb1-live-mv.v2h-cdn.com/hls/ffdc/tnn/tnn.m3u8', 'logo': 'https://n9.cl/l869p'},
    {'name': 'TPTV', 'url': 'https://lb1-live-mv.v2h-cdn.com/hls/ffec/tptv/tptv.m3u8', 'logo': 'https://n9.cl/b8u7i'},
    {'name': 'Amarin HD', 'url': 'https://lb1-live-mv.v2h-cdn.com/hls/ffad/amarin/amarin.m3u8', 'logo': 'https://n9.cl/65b58o'},
    {'name': 'Thairath HD', 'url': 'https://lb1-live-mv.v2h-cdn.com/hls/ffaf/thairath/thairath.m3u8', 'logo': 'https://n9.cl/409e5'},
    {'name': 'Channel 8', 'url': 'https://cdn-th-vip.login.in.th:443/ch8/ch8/chunklist.m3u8', 'logo': 'https://n9.cl/3gdhl'},
    {'name': 'Workpoint HD', 'url': 'https://global-media.sooplive.com/live/video/workpoint/1920x1080/playlist.m3u8', 'logo': 'https://n9.cl/dguzu'},
    {'name': 'Workpoint', 'url': 'https://lb1-live-mv.v2h-cdn.com/hls/ffcb/workpoint/workpoint.m3u8', 'logo': 'https://n9.cl/dguzu'},
    {'name': 'NBT', 'url': 'https://lb1-live-mv.v2h-cdn.com/hls/fffe/nbt/nbt.m3u8', 'logo': 'https://n9.cl/49yt5v'},
    {'name': 'CH5', 'url': 'https://lb1-live-mv.v2h-cdn.com/hls/fffb/5hd/5hd.m3u8', 'logo': 'https://bit.ly/3aaooNF'},
    {'name': 'Thai Chaiyo', 'url': 'https://live-iptv.thaichaiyo.tv/tcy/live-720P.m3u8', 'logo': 'https://n9.cl/y2z253'},
    {'name': 'JKN', 'url': 'https://lb1-live-mv.v2h-cdn.com/hls/ffda/jkn18/jkn18.m3u8', 'logo': 'https://n9.cl/unxb8'},
    {'name': 'Thai PBS', 'url': 'https://lb1-live-mv.v2h-cdn.com/hls/fffd/tpbs/tpbs.m3u8', 'logo': 'https://bit.ly/3R57wIK'},
    {'name': 'T Sport', 'url': 'https://lb1-live-mv.v2h-cdn.com/hls/ffef/tsport/tsport.m3u8', 'logo': 'https://n9.cl/ry89h'},
    {'name': 'Mono 29', 'url': 'https://lb1-live-mv.v2h-cdn.com/hls/ffbc/mono29/mono29.m3u8', 'logo': 'https://n9.cl/afnnk'},
    {'name': 'Mcot', 'url': 'https://lb1-live-mv.v2h-cdn.com/hls/ffbb/mcot/mcot.m3u8', 'logo': 'https://n9.cl/83jvz'},
    {'name': 'One', 'url': 'https://lb1-live-mv.v2h-cdn.com/hls/ffba/one/one.m3u8', 'logo': 'https://n9.cl/ipdj6'},
    {'name': 'PPTV', 'url': 'https://lb1-live-mv.v2h-cdn.com/hls/ffab/pptv/pptv.m3u8', 'logo': 'https://n9.cl/wmbwp'},
    {'name': 'GMM25', 'url': 'https://bcovlive-a.akamaihd.net/57d4bf695e80436d9335f4f50adbe438/ap-southeast-1/6415628290001/7e85dc4a59904e45b4fdffebd62e1d82/playlist_ssaiM.m3u8', 'logo': 'https://n9.cl/adt8o'},
    {'name': 'GMM25', 'url': 'https://lb1-live-mv.v2h-cdn.com/hls/ffbf/gmm25/gmm25.m3u8', 'logo': 'https://n9.cl/wmbwp'},
    {'name': 'True 24', 'url': 'https://lb1-live-mv.v2h-cdn.com/hls/ffca/true24/true24.m3u8', 'logo': 'https://n9.cl/0ws87l'},
    {'name': 'News 1', 'url': 'http://news1.live14.com/stream/news1.m3u8', 'logo': 'https://n9.cl/s9j3kg'}
]

#  (Movie)
movie_channels = [
    {'name': '🔴 หนังใหม่ 2024 - John Wick 4', 'url': 'https://server-cdn-streaming.com/movies/johnwick4.m3u8', 'logo': 'https://n9.cl/wick4'},
    {'name': '🔴 หนังใหม่ 2024 - The Creator', 'url': 'https://24-hd.com/movies/latest2024/creator.m3u8', 'logo': 'https://n9.cl/creator2024'},
    {'name': '🔴 หนังใหม่ 2025 - Avengers Legacy', 'url': 'https://server-cdn-streaming.com/movies2025/avengers5.m3u8', 'logo': 'https://n9.cl/avengers5'},
    {'name': '🔴 หนังไทย - บั้งไฟสไลเดอร์', 'url': 'https://cdn-movie.example.com/thai/bangfai2024.m3u8', 'logo': 'https://n9.cl/bangfai'},
    {'name': '🔴 หนังจีน - ดาบมังกรหยก 2025', 'url': 'https://asia-movie.example.com/chinese/swordlegend2025.m3u8', 'logo': 'https://n9.cl/swordlegend'}
]

# เมนูหลัก
def list_main_menu():
    items = [
        {'label': '📺 Live TV (ดูทีวีสด)', 'mode': 'live', 'thumb': 'https://n9.cl/4kmiht'},
        {'label': '🎬 หนังใหม่ล่าสุด', 'mode': 'movies', 'thumb': 'https://n9.cl/wick4'}
    ]
    for item in items:
        li = xbmcgui.ListItem(label=item['label'])
        li.setArt({'thumb': item['thumb'], 'icon': item['thumb'], 'fanart': item['thumb']})
        url = f"{sys.argv[0]}?mode={item['mode']}"
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

# แสดงรายการช่อง
def list_channels(channels):
    for ch in channels:
        li = xbmcgui.ListItem(label=ch['name'])
        li.setArt({'thumb': ch['logo'], 'icon': ch['logo'], 'fanart': ch['logo']})
        li.setInfo('video', {'title': ch['name'], 'mediatype': 'video'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=ch['url'], listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

# เริ่มต้น Addon
if __name__ == '__main__':
    if mode == 'live':
        list_channels(live_channels)
    elif mode == 'movies':
        list_channels(movie_channels)
    else:
        list_main_menu()
